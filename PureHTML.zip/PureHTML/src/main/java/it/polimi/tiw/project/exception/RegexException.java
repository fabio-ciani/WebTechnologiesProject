package it.polimi.tiw.project.exception;

public class RegexException extends Exception {
	public RegexException() {
		super();
	}

	public RegexException(String message) {
		super(message);
	}
}