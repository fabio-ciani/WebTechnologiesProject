package it.polimi.tiw.project.exception;

public class DuplicateNameException extends Exception {
	public DuplicateNameException() {
		super();
	}

	public DuplicateNameException(String message) {
		super(message);
	}
}