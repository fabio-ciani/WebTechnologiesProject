// https://stackoverflow.com/questions/17630307/mapping-filter-to-the-context-root-of-webapp-in-tomcat7

package it.polimi.tiw.project.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// Does not work with "/" (seems to not match the mapping or enter the first if, maybe because those are the welcome files)
@WebFilter({ "/", "/login.html", "/register.html" })
public class PreventLogging implements Filter {
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		HttpSession s = req.getSession();

		if (s.getAttribute("user") != null) {
			String baseURL = req.getServletContext().getContextPath();

			boolean rootReq = req.getRequestURI().equals(baseURL + "/");
			boolean loginReq = req.getRequestURI().equals(baseURL + "/login.html");
			boolean registerReq = req.getRequestURI().equals(baseURL + "/register.html");

			if (rootReq || loginReq || registerReq) {
				res.sendRedirect(req.getServletContext().getContextPath() + "/home");
				return;
			}
		}

		chain.doFilter(request, response);
	}
}