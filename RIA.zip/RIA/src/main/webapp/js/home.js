window.addEventListener("load", () => {
	if (sessionStorage.getItem("email") == null) {
		console.log("marameo")
		window.location.href = "login.html";
	} else {
		document.getElementById("user").textContent = sessionStorage.getItem("email");

		asyncCall("GET", "home", function(x) {
			// Could === operator be used?
			if (x.readyState == XMLHttpRequest.DONE) {
				var message = x.responseText;

				switch (x.status) {
					case 200:
						var ans = JSON.parse(message);

						var folders = ans[0];
						var subfolders = ans[1];

						if (folders.length == 0) {
							document.getElementById("no-folders").style.visibility = "visible";
							document.getElementById("tree").style.visibility = "hidden";
						} else {
							// TODO: show folders
							var fData = new FoldersLoader();
							fData.initialize(folders);
							if (Object.keys(subfolders).length == 0) {
								document.getElementById("no-subfolders").style.visibility = "visible";
							} else {
								var sData = new SubfoldersLoader();
								sData.initialize(subfolders);
								// TODO: show subfolders
							}
						}

						break;
					case 400:
						// document.getElementById("error").textContent = message;
						alert(message);
						break;
					case 403:
						window.location.href = x.getResponseHeader("Location");
						break;
					case 500:
						// document.getElementById("error").textContent = message;
						alert(message);
						break;
				}
			}
		});

		document.querySelector("a[href='logout']").addEventListener("click", () => {
			window.sessionStorage.removeItem("email");
		});
	}
});

function FoldersLoader() {
	this.roots = document.getElementById("tree");

	this.initialize = function(list) {
		this.roots.style.visibility = "visible";

		// Erase container content.
		this.roots.innerHTML = "";

		// Create file-tree structure.
		var container = document.createElement("ul");
		this.roots.appendChild(container);

		// Show folders list.
		var self = this;
		var element;
		list.forEach(function(f) {
			element = document.createElement("li");
			element.setAttribute("id", "f" + f["id"]);	// Generate unique HTML id.
			element.textContent = f["name"];

			container.appendChild(element);
		});
	};
}

function SubfoldersLoader() {
	this.initialize = function(map) {
		var parent;
		for (var key of Object.keys(map)) {
			// Query parent folder HTML element.
			parent = document.getElementById("f" + key);

			// Create a new tree level.
			var container = document.createElement("ul");

			// Show subfolders list.
			var element;
			map[key].forEach(function(s) {
				element = document.createElement("li");

				element.setAttribute("id", "s" + s["id"]);	// Generate unique HTML id.
				element.textContent = s["name"];
				// TODO: anchors

				container.appendChild(element);
			});

			parent.appendChild(container);
		}
	};
}
