window.addEventListener("load", () => {
	if (sessionStorage.getItem("email") == null) {
		window.location.href = "login.html";
	} else {
		document.getElementById("user").textContent = sessionStorage.getItem("email");

		asyncCall("GET", "home", function(x) {
			// Could === operator be used?
			if (x.readyState == XMLHttpRequest.DONE) {
				var message = x.responseText;

				switch (x.status) {
					case 200:
						var ans = JSON.parse(message);

						var folders = ans[0];
						var subfolders = ans[1];
						var documents = ans[2];

						if (folders.length == 0) {
							document.getElementById("tree").style.display = "none";
							document.getElementById("no-folders").style.removeProperty("display");
						} else {
							var fData = new FoldersLoader();
							fData.initialize(folders);

							if (Object.keys(subfolders).length != 0) {
								var sData = new SubfoldersLoader();
								sData.initialize(subfolders);
							}

							if (Object.keys(documents).length != 0) {
								var dData = new DocumentsLoader();
								dData.initialize(documents);
							}
						}

						break;
					case 500:
						// document.getElementById("error").textContent = message;
						alert(message);
						break;
				}
			}
		});

		document.getElementById("parent-creation").addEventListener("click", () => {
			var formNode = document.getElementById("form");

			// Reset <div> content.
			formNode.innerHTML = "";

			// Create HTML form.
			var form = document.createElement("form");
			form.style.visibility = "visible";

			var nameText = document.createElement("span");
			nameText.textContent = "Name: ";
			form.appendChild(nameText);

			var nameField = document.createElement("input");
			nameField.type = "text";
			nameField.name = "name";
			nameField.required = true;
			form.appendChild(nameField);

			// Insert line breaks.
			form.appendChild(document.createElement("br"));
			form.appendChild(document.createElement("br"));

			var btn = document.createElement("input");
			btn.type = "button";
			btn.value = "Create entity";
			btn.addEventListener("click", (e) => {
				var form = e.target.closest("form");

				if (form.checkValidity()) {
					formAsyncCall("POST", "FolderCreation", form, function(x) {
						// Could === operator be used?
						if (x.readyState == XMLHttpRequest.DONE) {
							var message = x.responseText;

							switch (x.status) {
								case 200:
									document.getElementById("tree").style.removeProperty("display");
									document.getElementById("no-folders").style.display = "none";

									var updater = new HomepageUpdater();
									updater.update();

									break;
								case 400:
								case 500:
									// document.getElementById("error").textContent = message;
									alert(message);
									break;
							}
						}
					});
				} else {
					form.reportValidity();
				}
			});
			form.appendChild(btn);

			formNode.appendChild(form);

			// Set table cell as visible.
			document.getElementById("form-container").style.visibility = "visible";

			// Update visual information.
			document.getElementById("root-creation").style.display = "inline";
			document.getElementById("entity-creation").style.display = "none";
		});

		document.querySelector("a[href='logout']").addEventListener("click", () => {
			window.sessionStorage.removeItem("email");
		});
	}
});

function HomepageUpdater() {
	this.update = function() {
		asyncCall("GET", "home", function(x) {
			// Could === operator be used?
			if (x.readyState == XMLHttpRequest.DONE) {
				var message = x.responseText;

				switch (x.status) {
					case 200:
						var ans = JSON.parse(message);

						var fData = new FoldersLoader();
						fData.initialize(ans[0]);

						var sData = new SubfoldersLoader();
						sData.initialize(ans[1]);

						break;
					case 500:
						// document.getElementById("error").textContent = message;
						alert(message);
						break;
				}
			}
		});
	}
}

function FoldersLoader() {
	this.roots = document.getElementById("tree");

	this.initialize = function(list) {
		// Erase container content.
		this.roots.innerHTML = "";

		// Create file-tree structure.
		var container = document.createElement("ul");
		this.roots.appendChild(container);

		// Show folders list.
		var self = this;
		var element, button;
		list.forEach(function(f) {
			element = document.createElement("li");
			element.setAttribute("id", "f" + f["id"]);	// Generate unique HTML id.
			element.textContent = f["name"];
			if (list.indexOf(f) == list.length - 1)
				element.className = "last";

			container.appendChild(element);

			button = document.createElement("input");
			button.type = "button";
			button.value = "Create subfolder";
			button.className = "create";
			button.setAttribute("folder_id", f["id"]);
			button.addEventListener("click", () => {
				var formNode = document.getElementById("form");

				// Reset <div> content.
				formNode.innerHTML = "";

				// Create HTML form.
				var form = document.createElement("form");
				form.style.visibility = "visible";

				var nameText = document.createElement("span");
				nameText.textContent = "Name: ";
				form.appendChild(nameText);

				var nameField = document.createElement("input");
				nameField.type = "text";
				nameField.name = "name";
				nameField.required = true;
				form.appendChild(nameField);

				var parentField = document.createElement("input");
				parentField.type = "hidden";
				parentField.name = "parent_folder";
				parentField.value = f["id"];
				form.appendChild(parentField);

				// Insert line breaks.
				form.appendChild(document.createElement("br"));
				form.appendChild(document.createElement("br"));

				var btn = document.createElement("input");
				btn.type = "button";
				btn.value = "Create entity";
				btn.addEventListener("click", (e) => {
					var form = e.target.closest("form");

					if (form.checkValidity()) {
						formAsyncCall("POST", "SubfolderCreation", form, function(x) {
							// Could === operator be used?
							if (x.readyState == XMLHttpRequest.DONE) {
								var message = x.responseText;

								switch (x.status) {
									case 200:
										var updater = new SubfoldersUpdater(f["id"]);
										updater.update();

										break;
									case 400:
									case 500:
										// document.getElementById("error").textContent = message;
										alert(message);
										break;
								}
							}
						});
					} else {
						form.reportValidity();
					}
				});
				form.appendChild(btn);

				formNode.appendChild(form);

				// Set table cell as visible.
				document.getElementById("form-container").style.visibility = "visible";

				// Update visual information.
				document.getElementById("root-creation").style.display = "none";
				document.getElementById("entity-creation").style.display = "inline";
				document.getElementById("entity").textContent = "subfolder";
				document.getElementById("target-entity").textContent = f["name"];
			});

			container.appendChild(button);

			container.appendChild(document.createElement("br"));
		});
	};
}

function SubfoldersUpdater(id) {
	this.id = id;

	this.update = function() {
		var self = this;

		asyncCall("GET", "subfolders?folder=" + self.id, function(x) {
			// Could === operator be used?
			if (x.readyState == XMLHttpRequest.DONE) {
				var message = x.responseText;

				switch (x.status) {
					case 200:
						var ans = new Object();
						ans[self.id] = JSON.parse(message);

						// Erase outdated content.
						document.getElementById("f" + self.id + "-subfolders").remove();

						var updater = new SubfoldersLoader();
						updater.initialize(ans);

						break;
					case 400:
					case 500:
						// document.getElementById("error").textContent = message;
						alert(message);
						break;
				}
			}
		});
	}
}

function SubfoldersLoader() {
	this.initialize = function(map) {
		var parent, target;
		for (var key of Object.keys(map)) {
			// Query parent folder HTML element.
			parent = document.getElementById("f" + key);
			target = parent.nextElementSibling.nextElementSibling;	// Obtain <br> tag.

			// Create a new tree level.
			var container = document.createElement("ul");
			container.setAttribute("id", "f" + key + "-subfolders");	// Generate unique HTML id.

			// Show subfolders list.
			var element, button;
			map[key].forEach(function(s) {
				element = document.createElement("li");

				element.setAttribute("id", "s" + s["id"]);	// Generate unique HTML id.
				element.textContent = s["name"];
				if (map[key].indexOf(s) == map[key].length - 1)
					element.className = "last";

				container.appendChild(element);

				button = document.createElement("input");
				button.type = "button";
				button.value = "Create document";
				button.className = "create";
				button.setAttribute("subfolder_id", s["id"]);
				button.addEventListener("click", () => {
					var formNode = document.getElementById("form");

					// Reset <div> content.
					formNode.innerHTML = "";

					// Create HTML form.
					var form = document.createElement("form");
					form.style.visibility = "visible";

					var text, field;
					var elements = ["name", "type", "summary"];
					elements.forEach(function(elem) {
						text = document.createElement("span");
						text.textContent = elem[0].toUpperCase() + elem.substring(1) + ": ";
						form.appendChild(text);

						var field = document.createElement("input");
						field.type = "text";
						field.name = elem;
						if (elem != "summary")
							field.required = true;
						form.appendChild(field);

						form.appendChild(document.createElement("br"));
					});

					var parentField = document.createElement("input");
					parentField.type = "hidden";
					parentField.name = "subfolder";
					parentField.value = s["id"];
					form.appendChild(parentField);

					// Insert line break.
					form.appendChild(document.createElement("br"));

					var btn = document.createElement("input");
					btn.type = "button";
					btn.value = "Create entity";
					btn.addEventListener("click", (e) => {
						var form = e.target.closest("form");

						if (form.checkValidity()) {
							formAsyncCall("POST", "DocumentCreation", form, function(x) {
								// Could === operator be used?
								if (x.readyState == XMLHttpRequest.DONE) {
									var message = x.responseText;

									switch (x.status) {
										case 200:
											var updater = new DocumentsUpdater(s["id"]);
											updater.update();

											break;
										case 400:
										case 500:
											// document.getElementById("error").textContent = message;
											alert(message);
											break;
									}
								}
							});
						} else {
							form.reportValidity();
						}
					});
					form.appendChild(btn);

					formNode.appendChild(form);

					// Set table cell as visible.
					document.getElementById("form-container").style.visibility = "visible";

					// Update visual information.
					document.getElementById("root-creation").style.display = "none";
					document.getElementById("entity-creation").style.display = "inline";
					document.getElementById("entity").textContent = "document";
					document.getElementById("target-entity").textContent = s["name"];
				});

				container.appendChild(button);

				container.appendChild(document.createElement("br"));
			});

			target.parentNode.insertBefore(container, target.nextSibling);
			// target.insertAdjacentHTML("afterend", container);
		}
	};
}

function DocumentsUpdater(id) {
	this.id = id;

	this.update = function() {
		var self = this;

		asyncCall("GET", "documents?subfolder=" + self.id, function(x) {
			// Could === operator be used?
			if (x.readyState == XMLHttpRequest.DONE) {
				var message = x.responseText;

				switch (x.status) {
					case 200:
						var ans = new Object();
						ans[self.id] = JSON.parse(message);

						// Erase outdated content.
						document.getElementById("s" + self.id + "-documents").remove();

						var updater = new DocumentsLoader();
						updater.initialize(ans);

						break;
					case 400:
					case 500:
						// document.getElementById("error").textContent = message;
						alert(message);
						break;
				}
			}
		});
	}
}

function DocumentsLoader() {
	this.initialize = function(map) {
		var parent, target;
		for (var key of Object.keys(map)) {
			// Query parent folder HTML element.
			parent = document.getElementById("s" + key);
			target = parent.nextElementSibling.nextElementSibling;	// Obtain <br> tag.

			// Create a new tree level.
			var container = document.createElement("ul");
			container.setAttribute("id", "s" + key + "-documents");	// Generate unique HTML id.

			// Show documents list.
			var element, button;
			map[key].forEach(function(d) {
				element = document.createElement("li");

				element.setAttribute("id", "d" + d["id"]);	// Generate unique HTML id.
				element.textContent = d["name"] + '.' + d["type"];
				if (map[key].indexOf(d) == map[key].length - 1)
					element.className = "last";

				container.appendChild(element);

				button = document.createElement("input");
				button.type = "button";
				button.value = "View detail";
				button.className = "detail";
				button.setAttribute("document_id", d["id"]);
				button.addEventListener("click", (e) => {
					/*
					asyncCall("GET", "detail?subfolder=" + d["subfolderID"] + "&document=" + d["id"], function(x) {
						// Could === operator be used?
						if (x.readyState == XMLHttpRequest.DONE) {
							var message = x.responseText;

							switch (x.status) {
								case 200:
									console.log(message);
									break;
								case 400:
								case 500:
									// document.getElementById("error").textContent = message;
									alert(message);
									break;
							}
						}
					});
					*/

					document.getElementById("detail-container").style.visibility = "visible";

					document.getElementById("title-document").textContent = d["name"] + '.' + d["type"];
					document.getElementById("title-subfolder").textContent = key;	// TODO
					// Query parent subfolder HTML element.
					var subfolder = e.target.closest("ul").previousSibling.previousSibling.previousSibling;
					document.getElementById("title-subfolder").textContent = subfolder.textContent;

					document.getElementById("detail-name").textContent = d["name"];
					document.getElementById("detail-type").textContent = "*." + d["type"];
					document.getElementById("detail-owner").textContent = sessionStorage.getItem("email");
					document.getElementById("detail-date").textContent = d["creation_date"];
					if (d["summary"].length == 0) {
						document.getElementById("summary").style.display = "none";
						document.getElementById("no-summary").style.removeProperty("display");
					} else {
						document.getElementById("summary").style.removeProperty("display");
						document.getElementById("detail-summary").textContent = d["summary"];
						document.getElementById("no-summary").style.display = "none";
					}
				});

				container.appendChild(button);

				container.appendChild(document.createElement("br"));
			});

			target.parentNode.insertBefore(container, target.nextSibling);
			// target.insertAdjacentHTML("afterend", container);
		}
	};
}
