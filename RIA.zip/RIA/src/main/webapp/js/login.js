(function() {
	document.getElementById("loginBtn").addEventListener("click", (e) => {
		var form = e.target.closest("form");

		if (form.checkValidity()) {
			formAsyncCall("POST", "login", form, function(x) {
				// Could === operator be used?
				if (x.readyState == XMLHttpRequest.DONE) {
					var message = x.responseText;

					switch (x.status) {
						case 200:
							sessionStorage.setItem("email", message);
							window.location.href = "home.html";
							break;
						case 400:
							document.getElementById("error").textContent = message;
							// alert(message);
							break;
						case 403:
							window.location.href = x.getResponseHeader("Location");
							break;
						case 500:
							document.getElementById("error").textContent = message;
							// alert(message);
							break;
					}
				}
			});
		} else {
			form.reportValidity();
		}

		// e.preventDefault() if <input type="submit"/> is used (?)
	});

	/*
	document.getElementById("registerAnchor").addEventListener("click", (e) => {
		asyncCall("GET", "register", function(x) {
			if (x.readyState == XMLHttpRequest.DONE) {
				var message = x.responseText;

				switch (x.status) {
					case 200:
						window.location.href = "register.html";
						break;
					case 400:
					case 401:
					case 500:
						// document.getElementById("error").textContent = message;
						alert(message);
						break;
				}
			}
		});

		e.preventDefault();
	});
	*/
})();
